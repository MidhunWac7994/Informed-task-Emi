import InsForm from './InstallmentFormSimple/InsForm'



function App() {


  return (
    <>
     <div>
{/* <InstallmentForm/> */}
< InsForm/>
      {/* <Form formData={formData}/> */}
 
     </div>
    </>
  )
}

export default App
